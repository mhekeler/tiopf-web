/*****************************************************************
  Create an interbase database to work with
*/

Create Database "C:\TechInsite\OPFPresentation\Source\3_SQLVisitors\Test.gdb"
user "SYSDBA" password "masterkey" ;

connect  "C:\TechInsite\OPFPresentation\Source\3_SQLVisitors\Test.gdb"
user "SYSDBA" password "masterkey" ;

create table People
  ( OID            Integer not null,
    Name           VarChar( 20 ),
    EMailAdrs      VarChar( 60 ),
    Primary Key    ( OID )) ;

create unique index People_uk on People ( name ) ;

insert into People values ( 1, "Peter Hinrichsen", "peter_hinrichsen@techinsite.com.au" ) ;
insert into People values ( 2, "Don Macrae", "don@xpro.com.au" ) ;
insert into People values ( 3, "Malcolm Groves", "malcolm@madrigal.com.au" ) ;

commit ;

/*
  Done
*/

